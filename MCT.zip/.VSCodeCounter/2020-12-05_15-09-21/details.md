# Details

Date : 2020-12-05 15:09:21

Directory x:\Programming\Python\NSE Stocks

Total : 21 files,  1203 codes, 45 comments, 257 blanks, all 1505 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [backend/commands.py](/backend/commands.py) | Python | 132 | 10 | 43 | 185 |
| [backend/database.py](/backend/database.py) | Python | 154 | 6 | 43 | 203 |
| [backend/main_server.py](/backend/main_server.py) | Python | 48 | 0 | 14 | 62 |
| [backend/server.py](/backend/server.py) | Python | 223 | 10 | 69 | 302 |
| [backend/server_def.py](/backend/server_def.py) | Python | 50 | 0 | 20 | 70 |
| [console.py](/console.py) | Python | 25 | 0 | 12 | 37 |
| [frontend/client.py](/frontend/client.py) | Python | 56 | 15 | 20 | 91 |
| [frontend/website/css/page.css](/frontend/website/css/page.css) | CSS | 5 | 0 | 1 | 6 |
| [frontend/website/css/sidebar-button.css](/frontend/website/css/sidebar-button.css) | CSS | 15 | 0 | 1 | 16 |
| [frontend/website/css/sidebar.css](/frontend/website/css/sidebar.css) | CSS | 4 | 0 | 1 | 5 |
| [frontend/website/css/titlebar.css](/frontend/website/css/titlebar.css) | CSS | 5 | 0 | 1 | 6 |
| [frontend/website/html/compra.html](/frontend/website/html/compra.html) | HTML | 30 | 0 | 6 | 36 |
| [frontend/website/html/home.html](/frontend/website/html/home.html) | HTML | 30 | 0 | 6 | 36 |
| [frontend/website/index.js](/frontend/website/index.js) | JavaScript | 10 | 0 | 5 | 15 |
| [frontend/website/js/help.js](/frontend/website/js/help.js) | JavaScript | 3 | 0 | 1 | 4 |
| [frontend/website/package-lock.json](/frontend/website/package-lock.json) | JSON | 372 | 0 | 1 | 373 |
| [pyinstaller/futurize-script.py](/pyinstaller/futurize-script.py) | Python | 9 | 2 | 2 | 13 |
| [pyinstaller/pasteurize-script.py](/pyinstaller/pasteurize-script.py) | Python | 9 | 2 | 2 | 13 |
| [run.py](/run.py) | Python | 9 | 0 | 3 | 12 |
| [start.bat](/start.bat) | Batch | 2 | 0 | 1 | 3 |
| [test.py](/test.py) | Python | 12 | 0 | 5 | 17 |

[summary](results.md)