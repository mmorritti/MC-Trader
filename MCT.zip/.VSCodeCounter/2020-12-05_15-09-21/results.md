# Summary

Date : 2020-12-05 15:09:21

Directory x:\Programming\Python\NSE Stocks

Total : 21 files,  1203 codes, 45 comments, 257 blanks, all 1505 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 11 | 727 | 45 | 233 | 1,005 |
| JSON | 1 | 372 | 0 | 1 | 373 |
| HTML | 2 | 60 | 0 | 12 | 72 |
| CSS | 4 | 29 | 0 | 4 | 33 |
| JavaScript | 2 | 13 | 0 | 6 | 19 |
| Batch | 1 | 2 | 0 | 1 | 3 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 21 | 1,203 | 45 | 257 | 1,505 |
| backend | 5 | 607 | 26 | 189 | 822 |
| frontend | 10 | 530 | 15 | 43 | 588 |
| frontend\website | 9 | 474 | 0 | 23 | 497 |
| frontend\website\css | 4 | 29 | 0 | 4 | 33 |
| frontend\website\html | 2 | 60 | 0 | 12 | 72 |
| frontend\website\js | 1 | 3 | 0 | 1 | 4 |
| pyinstaller | 2 | 18 | 4 | 4 | 26 |

[details](details.md)