function onHomeClick() {
    window.location.href.replace
}
